from django.db import models
from django.contrib.auth.models import User
from django.db.models import CASCADE

# Blood type choices
Blood_type_choices = [
	('A+', 'A+'),
	('A-', 'A-'),
	('B+', 'B+'),
	('B-', 'B-'),
	('AB+', 'AB+'),
	('AB-', 'AB-'),
	('O+', 'O+'),
	('O-', 'O-'),
]


# Donor model
class Donor(models.Model):
	Gender_choices = [
		('Male', 'Male'),
		('Female', 'Female'),
		('Other', 'Other'),
	]

	user = models.OneToOneField(User, on_delete=models.CASCADE, null=True, blank=True)
	first_name = models.CharField(max_length=50)
	last_name = models.CharField(max_length=50)
	dob = models.DateField()
	gender = models.CharField(max_length=10, choices=Gender_choices)
	phone = models.CharField(max_length=15, unique=True)
	email = models.EmailField(max_length=100, unique=True)
	address = models.TextField()
	blood_type = models.CharField(max_length=3, choices=Blood_type_choices, default='O+')
	last_donation_date = models.DateField(null=True, blank=True)

	def __str__(self):
		return f"{self.first_name} {self.last_name}"


# Donation model
class Donation(models.Model):
	donor = models.ForeignKey(Donor, on_delete=models.CASCADE)
	donation_date = models.DateTimeField()
	quantity = models.DecimalField(max_digits=10, decimal_places=2)
	blood_type = models.CharField(max_length=3, choices=Blood_type_choices)

	def __str__(self):
		return f"Donation by {self.donor} on {self.donation_date}"


# Patient model
class Patient(models.Model):
	GENDER_CHOICES = [
		('Male', 'Male'),
		('Female', 'Female'),
		('Other', 'Other'),
	]

	user = models.OneToOneField(User, on_delete=models.CASCADE, null=True, blank=True)
	first_name = models.CharField(max_length=50)
	last_name = models.CharField(max_length=50)
	dob = models.DateField(null=True, blank=True)
	blood_type = models.CharField(max_length=3, choices=Blood_type_choices, default='O+')
	gender = models.CharField(max_length=10, choices=GENDER_CHOICES, null=True, blank=True)
	phone = models.CharField(max_length=15, unique=True)
	email = models.EmailField(max_length=100, unique=True)
	address = models.TextField()

	def __str__(self):
		return f"{self.first_name} {self.last_name}"


# BloodRequest model
class BloodRequest(models.Model):
	STATUS_CHOICES = [
		('Pending', 'Pending'),
		('Fulfilled', 'Fulfilled'),
		('Cancelled', 'Cancelled'),
	]

	donor = models.ForeignKey(Donor, on_delete=models.CASCADE, null=True, blank=True)
	patient = models.ForeignKey(Patient, on_delete=models.CASCADE, null=True, blank=True)
	blood_type = models.CharField(max_length=3, choices=Blood_type_choices)
	quantity = models.DecimalField(max_digits=10, decimal_places=2)
	request_date = models.DateTimeField(auto_now_add=True)
	status = models.CharField(max_length=10, choices=STATUS_CHOICES, default='Pending')

	def __str__(self):
		return f"Request by {self.patient} for {self.quantity} units of {self.blood_type} on {self.request_date}"


# Transfusion model
class Transfusion(models.Model):
	blood_request = models.ForeignKey(BloodRequest, on_delete=models.CASCADE, null=True, blank=True)  # New ForeignKey
	donation = models.ForeignKey(Donation, on_delete=models.CASCADE)
	transfusion_date = models.DateTimeField()
	quantity = models.DecimalField(max_digits=10, decimal_places=2)
	status = models.CharField(max_length=10, choices=BloodRequest.STATUS_CHOICES)  # Reuse STATUS_CHOICES

	def __str__(self):
		return f"Transfusion for {self.blood_request.patient} on {self.transfusion_date}"


# Inventory model
class Inventory(models.Model):
	blood_type = models.CharField(max_length=3, choices=Blood_type_choices)
	quantity = models.DecimalField(max_digits=10, decimal_places=2)

	def __str__(self):
		return f"Inventory of {self.blood_type}: {self.quantity} units"


# Feedback model
class Feedback(models.Model):
	donor = models.ForeignKey(Donor, null=True, blank=True, on_delete=models.CASCADE)
	patient = models.ForeignKey(Patient, null=True, blank=True, on_delete=models.CASCADE)
	feedback = models.TextField()
	feedback_date = models.DateTimeField(auto_now_add=True)

	def __str__(self):
		return f"Feedback on {self.feedback_date}"
