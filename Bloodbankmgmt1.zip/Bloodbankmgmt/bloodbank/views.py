from xxlimited_35 import error

# from defer import return_value
from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, logout, login
#from netifaces import address_families
# from pysss import password
from decimal import Decimal
from django.contrib import messages

from django.shortcuts import render, get_object_or_404
# from requests import request
from datetime import datetime
from .models import *
from .models import BloodRequest, Donor, Patient, Donation, Feedback, Transfusion, Inventory


# Create your views here.

def About(request):
	return render(request, 'about.html')


def Contact(request):
	return render(request, 'contact.html')


def Index(request):
	return render(request, 'index.html')


# this is a admin login view
def admin_login(request):
	error = ""
	if request.method == 'POST':
		username = request.POST['adminname']
		password = request.POST['password']
		user = authenticate(request, username=username, password=password)

		if user is not None and user.is_staff:
			login(request, user)
			return redirect('admin_home')
			error = "no"
		else:
			error = "yes"

	return render(request, 'admin_login.html', {'error': error})


def admin_logout(request):
	if not request.user.is_staff:
		return redirect('admin_login')
	logout(request)
	return redirect('admin_login')


def Donor_login(request):
	return render(request, 'donor_login.html')


def Donor_signup(request):
	error = ""

	if request.method == 'POST':
		f = request.POST.get('fname')
		l = request.POST.get('lname')
		con = request.POST.get('contact')
		e = request.POST.get('email')
		b = request.POST.get('blood_type')
		gen = request.POST.get('gender')
		dob = request.POST.get('dob')
		a = request.POST.get('address')
		p = request.POST.get('pwd')

		try:

			user = User.objects.create_user(username=e, first_name=f, last_name=l, password=p)

			Donor.objects.create(
				user=user,
				phone=con,
				gender=gen,
				blood_type=b,
				dob=dob,
				email=e,
				address=a,
				first_name=f,
				last_name=l
			)
			error = "no"
		except:
			error = "yes"

	return render(request, 'donor_signup.html', {'error': error})


def donor_login(request):
	error = ""
	if request.method == "POST":
		d = request.POST.get('dname')  # Use get() to avoid KeyError if key is missing
		p = request.POST.get('pwd')

		# Authenticate user
		user = authenticate(request, username=d, password=p)
		if user:
			try:
				# Check if the user is a Donor
				Donor.objects.get(user=user)
				login(request, user)
				return redirect('donor_home')  # Redirect to donor home page
			except Donor.DoesNotExist:
				error = "yes"  # User is authenticated but not a Donor
		else:
			error = "yes"  # Authentication failed

	return render(request, 'donor_login.html', {'error': error})


def Patient_login(request):
	error = ""
	if request.method == "POST":
		u = request.POST['pname']
		p = request.POST['pwd']

		user = authenticate(username=u, password=p)
		if user:
			try:
				user1 = Patient.objects.get(user=user)
				login(request, user)
				error = "no"
				return redirect('patient_home')
			except Patient.DoesNotExist:
				error = "yes"
		else:
			error = "yes"

	d = {'error': error}
	return render(request, 'patient_login.html', d)


def Patient_signup(request):
	error = ""

	if request.method == 'POST':
		f = request.POST.get('fname')
		l = request.POST.get('lname')
		con = request.POST.get('contact')
		e = request.POST.get('email')
		b = request.POST.get('blood_type')
		gen = request.POST.get('gender')
		dob = request.POST.get('dob')
		a = request.POST.get('address')
		p = request.POST.get('pwd')

		try:
			# Create user
			user = User.objects.create_user(username=e, first_name=f, last_name=l, password=p)

			# Create patient record
			Patient.objects.create(
				user=user,
				phone=con,
				gender=gen,
				blood_type=b,
				dob=dob,
				email=e,
				address=a,
				first_name=f,
				last_name=l
			)
			error = "no"
		except:
			error = "yes"

	return render(request, 'patient_signup.html', {'error': error})


def Patient_home(request):
	if not request.user.is_authenticated:
		return redirect('patient_login')  # Redirect to the patient login page if not authenticated

	# Render the patient home page if the user is authenticated
	return render(request, 'patient_home.html')  # Render the template directly


def admin_home(request):
	if not request.user.is_authenticated:
		return redirect('admin_login')  # Redirect to the patient login page if not authenticated

	# Render the patient home page if the user is authenticated
	return render(request, 'admin_home.html')  # Render the template directly


def Logout(request):
	logout(request)  # Log the user out
	return redirect('home')  # Redirect to the home page


def donor_home(request):
	if not request.user.is_authenticated:
		return redirect('donor_login')  # Redirect to the donor login page if not authenticated

	# Render the donor home page if the user is authenticated
	return render(request, 'donor_home.html')  # Render the donor home template


def view_donor(request):
	if not request.user.is_authenticated:
		return redirect('admin_login')
	data = Donor.objects.all()
	d = {'data': data}
	return render(request, 'view_donor.html', d)


def view_patient(request):
	if not request.user.is_authenticated:
		return redirect('admin_login')
	data = Patient.objects.all()
	d = {'data': data}
	return render(request, 'view_patient.html', d)


def view_inventory(request):
	if not request.user.is_authenticated:
		return redirect('admin_login')
	data = Inventory.objects.all()
	k = {'data': data}
	return render(request, 'inventory.html', k)


# for delete donor information on admin panel

def delete_user(request, pid):
	if not request.user.is_authenticated:
		return redirect('admin_login')
	data = Donor.objects.get(id=pid)
	data.delete()
	return redirect('view_donor')

def edit_user(request, pid):
    if not request.user.is_authenticated:
        return redirect('admin_login')
    donor = Donor.objects.get(id=pid)  # Get the donor object
    if request.method == 'POST':
        donor.name = request.POST.get('name')  # Update the donor fields
        donor.email = request.POST.get('email')
        donor.blood_group = request.POST.get('blood_group')  # Example field
        # Add other fields as required
        donor.save()  # Save the updated donor object
        return redirect('view_donor')  # Redirect to the donor list view

    # Render a template for editing the donor
    return render(request, 'edit_donor.html', {'donor': donor})

def edit_patient(request, fid):
    if not request.user.is_authenticated:
        return redirect('admin_login')
    patient = Patient.objects.get(id=fid)
    if request.method == 'POST':
        patient.name = request.POST.get('name')
        patient.email = request.POST.get('email')
        patient.disease = request.POST.get('disease')
        patient.save()
        return redirect('view_patient')

    return render(request, 'edit_patient.html', {'patient': patient})



def delete_patient(request, fid):
	if not request.user.is_authenticated:
		return redirect('admin_login')
	data = Patient.objects.get(id=fid)
	data.delete()
	return redirect('view_patient')

def make_request(request):
    if request.method == 'POST':
        blood_type = request.POST.get('blood_type')
        quantity = float(request.POST.get('quantity'))  # Convert to float for comparison

        # Check if the quantity exceeds 3 units
        if quantity > 3:
            # Return an error message (you can customize this as needed)
            messages.error(request, "You cannot request more than 3 units of blood.")
            return render(request, 'make_request.html', {'blood_type_choices': Blood_type_choices})

        patient = request.user.patient
        # Uncomment and set values as needed
        # patient.first_name = first_name
        # patient.last_name = last_name
        # patient.contact = contact
        patient.save()

        # Create and save the blood request
        blood_request = BloodRequest(patient=patient, blood_type=blood_type, quantity=quantity)
        blood_request.save()

        # Redirect to request history or another page
        return redirect('request_history', cid=patient.id)

    blood_type_choices = Blood_type_choices

    return render(request, 'make_request.html', {'blood_type_choices': blood_type_choices})

def request_history(request, cid):
	# here this line either get object of patient or 404 error
	patient = get_object_or_404(Patient, id=cid)
	requests = BloodRequest.objects.filter(patient=patient).order_by('-request_date')

	context = {
		'patient': patient,
		'requests': requests,
	}

	return render(request, 'request_history.html', context)


def make_request_donor(request):
	if request.method == 'POST':
		blood_type = request.POST.get('blood_type')
		quantity = request.POST.get('quantity')

		donor = request.user.donor
		# patient.first_name = first_name (uncomment this if first name....ana all not showing )
		# patient.last_name = last_name
		# patient.contact = contact
		donor.save()

		blood_request = BloodRequest(donor=donor, blood_type=blood_type, quantity=quantity)
		blood_request.save()

		# Redirect to request history or another page
		return redirect('request_history_donor', kid=donor.id)

	blood_type_choices = Blood_type_choices

	return render(request, 'make_request_donor.html', {'blood_type_choices': blood_type_choices})


def request_history_donor(request, kid):
	donor = get_object_or_404(Donor, id=kid)
	requests = BloodRequest.objects.filter(donor=donor).order_by('-request_date')

	context = {
		'donor': donor,
		'requests': requests,
	}

	return render(request, 'request_history_donor.html', context)


def donate_blood(request):
	if not request.user.is_authenticated:
		return redirect('donor_login')

	if request.method == 'POST':
		# Get data from the form
		blood_type = request.POST.get('blood_type')
		quantity = request.POST.get('quantity')

		# Validate and convert quantity to Decimal
		try:
			quantity = Decimal(quantity)
		except:
			# Handle invalid input case and re-render the form with an error message
			return render(request, 'donate_blood.html', {
				'blood_type_choices': Blood_type_choices,
				'error_message': 'Invalid quantity. Please enter a valid number.'
			})

		# Get the donor object associated with the logged-in user
		donor = request.user.donor

		# Step 1: Create a Donation record
		donation = Donation(
			donor=donor,
			blood_type=blood_type,
			quantity=quantity,
			donation_date=datetime.now()  # Use timezone.now() instead of datetime.now()
		)
		donation.save()

		# Step 2: Update Inventory
		try:
			# Check if there is already an inventory record for this blood type
			inventory = Inventory.objects.get(blood_type=blood_type)
			inventory.quantity += quantity  # Increase the quantity
			inventory.save()
		except Inventory.DoesNotExist:
			# If there is no inventory record for this blood type, create a new one
			Inventory.objects.create(blood_type=blood_type, quantity=quantity)

		# Redirect to a success page or back to donor dashboard
		return redirect('donor_home')

	# Render the donation form with blood type choices for non-POST requests
	blood_type_choices = Blood_type_choices
	return render(request, 'donate_blood.html', {'blood_type_choices': blood_type_choices})


def new_patient_requests(request):
	if not request.user.is_authenticated:
		return redirect('admin_login')

	# Get all pending blood requests
	new_requests = BloodRequest.objects.filter(status='Pending').order_by('-request_date')

	# Handle status update
	if request.method == 'POST':
		request_id = request.POST.get('request_id')
		action = request.POST.get('action')
		blood_request = get_object_or_404(BloodRequest, id=request_id)

		if action == 'accept':
			blood_request.status = 'Accepted'
			messages.success(request, 'Request has been accepted.')
		elif action == 'reject':
			blood_request.status = 'Rejected'
			messages.success(request, 'Request has been rejected.')
		elif action == 'pending':
			blood_request.status = 'Pending'
			messages.info(request, 'Request is now pending.')

		blood_request.save()
		return redirect('new_patient_requests')  # Refresh the page to show updated status

	context = {
		'new_requests': new_requests
	}
	return render(request, 'new_patient_requests.html', context)
from django.contrib import messages

