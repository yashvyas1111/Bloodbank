from django.contrib import admin
from .models import Patient, Donor, Donation, Transfusion, Inventory, Feedback, BloodRequest


@admin.register(Patient)
class PatientAdmin(admin.ModelAdmin):
    list_display = ('first_name', 'last_name', 'dob', 'blood_type', 'gender', 'phone', 'email')
    search_fields = ('first_name', 'last_name', 'email', 'phone')
    list_filter = ('blood_type', 'gender', 'dob','first_name')

@admin.register(Donor)
class DonorAdmin(admin.ModelAdmin):
    list_display = ('first_name', 'last_name', 'dob', 'gender', 'phone', 'email', 'blood_type')
    search_fields = ('first_name', 'last_name', 'email', 'phone')
    list_filter = ('blood_type', 'gender', 'dob', 'first_name')


@admin.register(Donation)
class DonationAdmin(admin.ModelAdmin):
    list_display = ('donor', 'donation_date', 'quantity', 'blood_type')

@admin.register(BloodRequest)
class BloodRequestAdmin(admin.ModelAdmin):
    list_display = ('patient', 'donor', 'blood_type', 'quantity', 'request_date', 'status')
    list_editable = ('status',)  # Allows inline editing of the 'status' field
    list_filter = ('status', 'blood_type', 'request_date')  # Adds filtering options
    search_fields = ('patient__first_name', 'patient__last_name', 'donor__first_name', 'donor__last_name')



@admin.register(Transfusion)
class TransfusionAdmin(admin.ModelAdmin):
    list_display = ('blood_request', 'donation', 'transfusion_date', 'quantity', 'status')

@admin.register(Inventory)
class InventoryAdmin(admin.ModelAdmin):
    list_display = ('blood_type', 'quantity')

@admin.register(Feedback)
class FeedbackAdmin(admin.ModelAdmin):
    list_display = ('donor', 'patient', 'feedback', 'feedback_date')
