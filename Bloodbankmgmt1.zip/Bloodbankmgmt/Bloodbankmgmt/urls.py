"""Bloodbankmgmt URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/3.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.conf import settings
from django.contrib import admin
from django.urls import path
from bloodbank.views import *
from django.conf.urls.static import static

urlpatterns = [

				  path('admin/', admin.site.urls),
				  path('about/', About, name='about'),
				  path('', Index, name='home'),
				  path('admin_login/', admin_login, name='admin_login'),
				  path('admin_logout/', admin_logout, name='admin_logout'),
				  path('contact/', Contact, name='contact'),
				  path('donor_login/', donor_login, name='donor_login'),
				  path('donor_signup/', Donor_signup, name='donor_signup'),
				  path('patient_login/', Patient_login, name='patient_login'),
				  path('patient_signup/', Patient_signup, name='patient_signup'),
				  path('patient_home/', Patient_home, name='patient_home'),
				  path('Logout/', Logout, name='Logout'),
				  path('admin_home/', admin_home, name='admin_home'),
				  path('donor_home/', donor_home, name='donor_home'),
				  path('view_donor/', view_donor, name='view_donor'),
				  path('view_patient/', view_patient, name='view_patient'),
				  path('delete_user/<int:pid>', delete_user, name='delete_user'),
				  path('delete_patient/<int:fid>', delete_patient, name='delete_patient'),
				  path('make_request/', make_request, name='make_request'),
				  path('request_history/<int:cid>', request_history, name='request_history'),
				  path('make_request_donor/', make_request_donor, name='make_request_donor'),
				  path('request_history_donor/<int:kid>', request_history_donor, name='request_history_donor'),
				  path('inventory/', view_inventory, name='inventory'),
				  path('donate_blood/', donate_blood, name='donate_blood'),
				  path('new_patient_requests/', new_patient_requests, name='new_patient_requests'),
				  path('edit_user/<int:pid>', edit_user, name='edit_user'),
				  path('edit_patient/<int:fid>', edit_patient, name='edit_patient'),

			  ] + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
